export const styleEntry = 'styles/import-order.css';
export const blockInventoryPath = 'manifests/block-inventory.json';
export const tokenManifestPath = 'manifests/design-tokens.json';
export const dependencyManifestPath = 'manifests/dropin-dependencies.json';
export const sectionConventionManifestPath = 'manifests/section-conventions.json';
export const assetManifestPath = 'manifests/assets.json';
