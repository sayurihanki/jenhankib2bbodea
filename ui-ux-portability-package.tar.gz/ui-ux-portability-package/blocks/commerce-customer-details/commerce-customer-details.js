import { render as orderRenderer } from '@dropins/storefront-order/render.js';
import { CustomerDetails } from '@dropins/storefront-order/containers/CustomerDetails.js';

// Initialize
import '../../scripts/initializers/order.js';

export default async function decorate(block) {
  await orderRenderer.render(CustomerDetails, {})(block);
}
