# Design System and UX Reference

## Design Direction

- Visual style: glassmorphic layers on a warm neutral base.
- Primary accent token: `--main-color-accent`.
- Typography stack: Adobe Clean + Roboto variants.
- Motion language: eased lifts, staggered entrance, orb drift background.

## Key Global Conventions

- Root token system in `styles/styles.css`.
- Global motion add-ons in `styles/lazy-styles.css`.
- Font declarations in `styles/fonts.css`.
- Section-level visual controls via classes and metadata attributes.

## Responsive Breakpoints (Detected)

- `1024px`
- `600px`
- `900px`

## Header/Nav Design Tokens

- `--nav-dropdown-radius`
- `--nav-flyout-bg`
- `--nav-flyout-border`
- `--nav-flyout-shadow`
- `--nav-highlight-bg`
- `--nav-highlight-bg-selected`
- `--nav-highlight-border`
- `--nav-highlight-shadow`
- `--nav-hover-radius`
- `--nav-interaction-speed`
- `--nav-live-search-bg`
- `--nav-live-search-border`
- `--nav-live-search-radius`
- `--nav-live-search-shadow`
- `--nav-live-search-width`
- `--nav-overlay-blur`

## Component Inventory Summary

- Total blocks: `110`
- Blocks with CSS: `110`
- Blocks with JS runtime: `110`

Category distribution:
- `interactive-content`: 9
- `content`: 37
- `commerce`: 55
- `shell`: 5
- `forms`: 4

## Token Prefix Distribution

- `accent`: 3
- `background`: 2
- `blogpost`: 1
- `body`: 4
- `circle`: 4
- `color`: 63
- `column`: 1
- `cream`: 1
- `d`: 1
- `desktop`: 5
- `dialog`: 1
- `ease`: 3
- `f2`: 15
- `f3`: 15
- `f4`: 20
- `featured`: 1
- `float`: 1
- `font`: 1
- `gap`: 1
- `glass`: 9
- `gold`: 2
- `green`: 10
- `grid`: 15
- `header`: 1
- `hero`: 34
- `hiws`: 22
- `ink`: 11
- `light`: 1
- `live`: 21
- `luxury`: 14
- `main`: 1
- `minifiedView`: 1
- `nav`: 17
- `newsletter`: 28
- `no`: 1
- `pcl`: 5
- `pp`: 8
- `promotional`: 51
- `quiz`: 11
- `readonly`: 1
- `search`: 26
- `sel`: 1
- `shadow`: 5
- `shape`: 15
- `sl`: 70
- `slide`: 1
- `spacing`: 13
- `store`: 3
- `tertiary`: 1
- `text`: 1
- `top`: 7
- `transition`: 3
- `type`: 48
- `uc`: 1
- `vip`: 20
- `vmb`: 3
- `width`: 1
- `yes`: 1
